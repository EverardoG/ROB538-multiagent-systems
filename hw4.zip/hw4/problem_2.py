from staghunt import *

np.random.seed(0)

# Problem 2a
runChoosingProblem(num_episodes=500, epsilon_off=0, epsilon=0.1, alpha=0.05, filename=None)
